This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## How to run:
- Open a terminal/command line in a directory where you want to save the project to
- Checkout the project

```
git clone https://github.com/chrisblakely01/basic-react-forms.git

```

- Navigate to project in the terminal
- Install the project:

```
npm install
```

- Start the project 

```
npm start
```
